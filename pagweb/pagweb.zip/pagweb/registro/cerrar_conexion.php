<?php
	mysql_close($conexion);
?>